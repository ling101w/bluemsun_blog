const FALLBACK_API_BASE_URL = 'http://8.211.138.24:8080/api'
const FALLBACK_API_ORIGIN = 'http://8.211.138.24:8080'

const rawApiBaseUrl = (import.meta.env.VITE_API_BASE_URL || '').trim()

export const API_BASE_URL = rawApiBaseUrl || FALLBACK_API_BASE_URL

export const API_ORIGIN = (() => {
  try {
    return new URL(API_BASE_URL).origin
  } catch {
    return FALLBACK_API_ORIGIN
  }
})()
